package fruitkiezer;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 *
 */
public class FruitkiezerCompanion {

    public ComboBox<String> combo;

    public ImageView imageview;
    
    private static final ObservableList<String> OPTIONS
                = FXCollections.observableArrayList(
                        "aardbei",
                        "ajuin",
                        "ananas",
                        "appel",
                        "asperge",
                        "banaan",
                        "broccoli",
                        "druiven",
                        "framboos",
                        "kiwi",
                        "mais",
                        "meloen",
                        "peer",
                        "peper",
                        "perzik",
                        "pickle",
                        "pompelmoes",
                        "tomaat",
                        "watermeloen",
                        "wortel"
                );

    public void handleButtonAction() {
        imageview.setImage(new Image("/fruit/" + combo.getValue() + ".png"));
    }

    public void initialize() {
            combo.setItems(OPTIONS);
            imageview.setImage(new Image("/fruit/unknown.png"));
    }

}
