open module fruitkiezer {

    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.fxml;
}
