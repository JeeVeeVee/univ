package vieroprij;


public class Oplossing extends Model {

    private enum Kleur { Geel, Rood }
    private final Kleur[][] bord = new Kleur[Config.NUM_ROWS][Config.NUM_COLUMNS];
    private Kleur speler = Kleur.Geel;

    private boolean gameOver = false;

    private int numberOfMoves = 0;

    private Kleur geefKleur(int row, int column) {
        if (row >= 0 && row < Config.NUM_ROWS) {
            if (column >= 0 && column < Config.NUM_COLUMNS) {
                return bord[row][column];
            }
        }
        return null;
    }

    /**
     * If a new move causes the game to end
     * then the game-over property must be modified,
     * so that all listeners are notified of this fact.
     */
    private void checkGameOver(int row, int column) {
        boolean vierOpEenRij = false;
        for (int[] dir : new int[][]{{1, 0}, {1, 1}, {0, 1}, {-1, 1}}) {
            int count = 1;
            for (int i = 1; i < 4; ++i) {
                if (geefKleur(row + i * dir[0], column + i * dir[1]) == speler) {
                    count += 1;
                } else {
                    break;
                }
            }
            for (int i = -1; i > -4; --i) {
                if (geefKleur(row + i * dir[0], column + i * dir[1]) == speler) {
                    count += 1;
                } else {
                    break;
                }
            }
            if (count >= 4) {
                vierOpEenRij = true;
                break;
            }
        }
        if (vierOpEenRij || numberOfMoves == Config.NUM_COLUMNS*Config.NUM_ROWS) {
            System.out.println("Game over!");
            this.gameOver = true;
            notifyListeners(vierOpEenRij);
        }
    }

    /**
     * Check if a new disc can be inserted in the current column.
     * @param column
     * @return true if and only if a move in this column is allowed.
     */
    public boolean isPlayableMove(int column) {
        // No moves are allowed when the game is over.
        if (gameOver) {
            return false;
        }
        int dest = moveDestination(column);
        return dest >= 0 && dest < Config.NUM_ROWS;
    }

    /**
     * Compute the final destination row of a candidate move.
     * @param column The column in which a disc is going to be played.
     * @return The row where the disc will eventually be stored.
     */
    public int moveDestination(int column) {
        for (int row = Config.NUM_ROWS - 1; row >= 0; --row) {
            if (bord[row][column] == null) {
                return row;
            }
        }
        return Integer.MIN_VALUE;
    }

    /**
     * A new move is committed to the model when the move animation has ended.
     * Commit the insertion of a new disc in a given column and update game state.
     * @param column The column in which a new disc has been inserted.
     */
    public void playMove(int column) {
        if (gameOver || !isPlayableMove(column)) {
            throw new IllegalArgumentException("playMove");
        }
        int dest = moveDestination(column);

        // Update the model to reflect the new move.
        bord[dest][column] = speler;
        numberOfMoves ++;

        // Also check for termination conditions.
        checkGameOver(dest, column);

        // Change colors for the next move.
        speler = speler == Kleur.Geel ? Kleur.Rood : Kleur.Geel;
    }
}
