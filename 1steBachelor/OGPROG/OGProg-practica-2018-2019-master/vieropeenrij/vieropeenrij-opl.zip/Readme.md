Vier op een rij - oplossing
===============

Dit is een oplossing voor de oefening `vieroprij`. 

* In plaats van `Model` aan te passen, gebruiken we een extensie `Oplossing` van die
klasse
* De klasse `VierOpRij` is lichtjese aangepast om een model van het type `Oplossing` te 
gebruiken (zie lijn 45).