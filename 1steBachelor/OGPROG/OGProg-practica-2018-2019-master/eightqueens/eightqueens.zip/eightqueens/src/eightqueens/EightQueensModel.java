package eightqueens;

import java.util.ArrayList;
import java.util.List;

/**
 * Model voor deze toepassing. Bevat alle gegevens die nodig zijn om het bord te kunnen afbeelden.
 */
public class EightQueensModel {

    /*
     * Je zal wellicht enkele velden nodig hebben om informatie bij te houden over waar de koninginnen
     * staan en of een veld door een koningin bedreigt wordt of niet.
     *
     * Je mag aannemen dat het bord dat we gebruiken steeds 8 rijen en 8 kolommen heeft.
     *
     * Tip: houd van elke veld bij *hoeveel keer* het wordt bedreigt, dit maakt het eenvoudiger om
     * een koningin terug weg te nemen zonder dat je alle gegevens opnieuw moet herberekenen.
     */


    /**
     * Het hoofdprogramma roept de constructor zonder argumenten op om een nieuw model aan te maken.
     */
    public EightQueensModel() {

    }

    /**
     * Deze methode wordt gebruikt door de luisteraars om zichzelf bij het model te registreren.
     * @param listener Luisteraar die moet worden geregistreerd.
     */
    public void registerListener(EightQueensListener listener) {
        // TODO
    }

    /*
     * Onderstaande methoden worden gebruikt door luisteraars om te weten  hoe het bord eruit ziet
     */

    /**
     * Staat er een dame op de gegeven positie?
     * @param row Rijnummer van de bedoelde positie (0..7)
     * @param column Kolomnummer van de bedoelde positie (0..7)
     */
    public boolean hasQueen (int row, int column) {
        // TODO: aanpassen. Verander dit bijvoorbeeld eerst eens in true om te zien wat het effect is.
        return false;
    }

    /**
     * Wordt de gegeven positie bedreigd?
     * @param row Rijnummer van de bedoelde positie (0..7)
     * @param column Kolomnummer van de bedoelde positie (0..7)
     */
    public boolean isThreatened (int row, int column) {
        // TODO
        return false;
    }

    /*
     * Onderstaande methoden worden gebruikt door de controllers om de inhoud van het bord te veranderen.
     * Let erop dat je bij elke verandering *alle* luisteraars op de hoogte brengt dat er iets is veranderd
     * door hun methode {@link EightQueensListener#modelHasChanged} op te roepen.
     */

    /**
     * Als er een koningin staat op de gegeven positie, verwijder ze dan
     * Is het veld leeg, en wordt het niet bedreigd, plaats dan een koningin.
     * Is het veld leeg en wordt het veld wel bedreigd, dan doe je niets.
     * @param row Rijnummer van de bedoelde positie (0..7)
     * @param column Kolomnummer van de bedoelde positie (0..7)
     *
     */
    public void toggleQueen(int row, int column) {
        // TODO
    }


    /**
     * Maak het veld volledig leeg.
     */
    public void cleanAll () {
        // TODO
    }

}
