open module eightqueens {
    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.fxml;
}