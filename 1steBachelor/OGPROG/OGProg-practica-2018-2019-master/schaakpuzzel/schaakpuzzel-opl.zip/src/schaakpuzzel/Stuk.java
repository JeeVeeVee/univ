package schaakpuzzel;

/**
 * Schaakstuk
 */
public abstract class Stuk {


    /**
     * Letter waarmee het stuk wordt voorgesteld.
     */
    private char letter;

    public char getLetter() {
        return letter;
    }

    protected Stuk (char letter) {
        this.letter = letter;
    }

    /**
     * Geeft aan of dit stuk de opgegeven positie bedreigt.
     */
    public abstract boolean bedreigt(Positie positie);


    /**
     * Positie waarop het stuk zich bevindt.
     */
    protected Positie pos;

    public Positie getPositie() {
        return pos;
    }

    public void setPositie(Positie pos) {
        this.pos = pos;
    }
}