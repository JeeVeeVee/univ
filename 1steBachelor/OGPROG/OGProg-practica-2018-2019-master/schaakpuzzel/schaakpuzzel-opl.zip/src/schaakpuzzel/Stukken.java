package schaakpuzzel;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.function.Supplier;

public final class Stukken {

    private static final Map<Character, Supplier<Stuk>> map = new HashMap<>();

    static {
        map.put('P', Paard::new);
        map.put('L', Loper::new);
        map.put('T', Toren::new);
        map.put('D', Dame::new);
        map.put('A', Amazone::new);
    } // in Java 9 kan dit nog korter genoteerd worden mbv Map.of(...)

    public static Stuk create(char letter) {
        if (Character.isLowerCase(letter)) {
            letter = Character.toUpperCase(letter);
        }
        Supplier<Stuk> factory = map.get(letter);
        if (factory == null) {
            throw new NoSuchElementException("Ongeldige stukletter.");
        }
        return factory.get();
    }
}

