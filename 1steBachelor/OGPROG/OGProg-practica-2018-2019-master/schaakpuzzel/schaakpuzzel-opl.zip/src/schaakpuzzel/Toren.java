package schaakpuzzel;

/**
 * Toren is rechttoe-rechtaan.
 */
public class Toren extends Stuk {

    public Toren () {
        super ('T');
    }

    @Override
    public boolean bedreigt(Positie positie) {
        return pos.isTorenzet(positie);
    }
}