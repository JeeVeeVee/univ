package schaakpuzzel;

public class Paard extends Stuk {

    public Paard() {
        super ('P');
    }

    @Override
    public boolean bedreigt(Positie positie) {
        return pos.isPaardensprong(positie);
    }
}
