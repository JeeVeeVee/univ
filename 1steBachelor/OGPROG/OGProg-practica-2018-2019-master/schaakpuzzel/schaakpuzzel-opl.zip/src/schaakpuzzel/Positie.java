package schaakpuzzel;

public class Positie {

    private int rij;
    private int kol;

    public Positie(int rij, int kol) {
        if (rij < 0 || rij > 7 || kol < 0 || kol > 7) {
            throw new IllegalArgumentException("Ongeldige bordpositie.");
        }
        this.rij = rij;
        this.kol = kol;
    }

    public int getRij() {
        return rij;

    }

    public int getKolom() {
        return kol;
    }

    public boolean isPaardensprong(Positie pos) {
        // Dit is een wiskundig truukje: de enige  gehele getallen waarvoor a*a+b*b==5, zijn
        // a,b=±1,±2 of a,b=±2,±1 - precies de 'afstanden' voor een paardensprong
        return 5 == (rij - pos.rij) * (rij - pos.rij) + (kol - pos.kol) * (kol - pos.kol);
    }

    public boolean isLoperzet(Positie pos) {
        return rij + kol == pos.rij + pos.kol
                || rij - kol == pos.rij - pos.kol;
    }

    public boolean isTorenzet(Positie pos) {
        return rij == pos.rij || kol == pos.kol;
    }
}
