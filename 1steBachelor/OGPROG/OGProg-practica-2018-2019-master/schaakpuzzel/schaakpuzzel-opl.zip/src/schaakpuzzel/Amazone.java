package schaakpuzzel;

public class Amazone extends Stuk {

    public Amazone () {
        super ('A');
    }

    @Override
    public boolean bedreigt(Positie to) {
        return pos.isPaardensprong(to) || pos.isLoperzet(to) || pos.isTorenzet(to);
    }
}
