package schaakpuzzel;

public class Loper extends Stuk {

    public Loper () {
        super ('L');
    }

    @Override
    public boolean bedreigt(Positie positie) {
        return pos.isLoperzet(positie);
    }
}
