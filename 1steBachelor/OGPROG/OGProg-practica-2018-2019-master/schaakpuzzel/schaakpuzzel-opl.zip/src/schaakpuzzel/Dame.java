package schaakpuzzel;

public class Dame  extends Stuk {

    public Dame() {
        super('D');
    }

    @Override
    public boolean bedreigt(Positie positie) {
        return pos.isLoperzet(positie) || pos.isTorenzet(positie);
    }
}
