Schaakpuzzel - oplossing
===

**Opmerkingen** 

* Deze oplossing definieert geen afzonderlijke
interface voor *factories*. Factories worden in de plaats geïmplementeerd als 'lambda's' die
aan de interface *Supplier* voldoen, zoals beschreven op de laatste pagina van
hoofdstuk 2 in de cursusnota's.

* We zijn hier vrij ver gegaan in het objectgericht maken van de oplossing. We hebben
bijvoorbeeld een nieuwe klasse *Positie* ingevoerd: een combinatie van rij en
kolomnummer met bovendien enkele bijkomende methoden om gemakkelijk te kunnen
kijken of twee posities op dezelfde rij of kolom liggen, of een paardensprong
 van elkaar verwijderd zijn. 