open module muizenhuis {
    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.fxml;
}