package muizenhuis;

/**
 * Alle mogelijke toestanden
 */
public class Toestanden {

    /* Implementeer de verschillende binnenklassen voor elk van de 7 toestanden. Kies betekenisvolle namen voor
       deze klassen, zoals Basis, LinksBegin, LinksMidden, LinksEinde, …, en *niet* Toestand0, Toestand1, ….

       De rest van het programma verwacht trouwens dat de begintoestand Basis heet.

       Het is wellicht nuttig om een gemeenschappelijke boven(binnen)klasse te introduceren voor deze 7 klassen.
     */

     public static class Basis implements Toestand {
         // Onderstaande implementatie moet worden aangepast!

         @Override
         public Toestand linksAan(Kamers kamers) {
             return this;
         }

         @Override
         public Toestand linksUit(Kamers kamers) {
             return this;
         }

         @Override
         public Toestand rechtsAan(Kamers kamers) {
             return this;
         }

         @Override
         public Toestand rechtsUit(Kamers kamers) {
             return this;
         }
     }

}
