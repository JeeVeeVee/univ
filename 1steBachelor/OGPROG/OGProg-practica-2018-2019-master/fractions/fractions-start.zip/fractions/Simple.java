package fractions;

/**
 * Eenvoudige uitdrukking. Bestaat uit één enkele string.
 */
public class Simple extends Expression {

    private String text;

    public Simple(String text) {
        this.text = text;
    }

    // code niet wijzigen! Wordt gebruikt om te debuggen.
    public String toString() {
        return text;
    }

    @Override
    public void computeWidth() {
        // TODO
    }

    @Override
    public void computeHeightAndDepth() {
        // TODO
    }

    @Override
    public void computeCoordinates() {
        // TODO
    }

    @Override
    public char charAt(int rij, int kolom) {
        return ' '; // TODO
    }
}
