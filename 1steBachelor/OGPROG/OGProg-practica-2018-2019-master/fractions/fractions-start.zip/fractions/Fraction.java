package fractions;

/**
 * Een teller en noemer met een breukstreep ertussen. Teller en noemer zijn horizontaal
 * gecenteerd. Breukstreep staat op de 'baseline'.
 */
public class Fraction extends Expression {

    private Expression top;

    private Expression bottom;

    public Fraction(Expression top, Expression bottom) {
        this.top = top;
        this.bottom = bottom;
    }

    // code niet wijzigen! Wordt gebruikt om te debuggen.
    public String toString() {
        return "[" + top + "/" + bottom + "]";
    }

    @Override
    public void computeWidth() {
        // TODO
    }

    @Override
    public void computeHeightAndDepth() {
        // TODO
    }

    @Override
    public void computeCoordinates() {
        // TODO
    }

    @Override
    public char charAt(int rij, int kolom) {
        return ' '; // TODO
    }

}
