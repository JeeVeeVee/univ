package fractions;

import java.util.List;

/**
 * Een reeks uitdrukkingen die naast elkaar worden afgebeeld, met telkens
 * één spatie ertussen
 */
public class Sequence extends Expression {

    public Sequence(List<Expression> children) {
        this.children = children;
    }

    private List<Expression> children;

    // code niet wijzigen! Wordt gebruikt om te debuggen.
    public String toString() {
        if (children.isEmpty()) {
            return "{}";
        } else {
            StringBuilder result = new StringBuilder();
            for (Expression child : children) {
                result.append(" ").append(child);
            }
            return "{" + result.substring(1) + "}";
        }
    }


    @Override
    public void computeWidth() {
        // TODO
    }

    @Override
    public void computeHeightAndDepth() {
        // TODO
    }

    @Override
    public void computeCoordinates() {
        // TODO
    }

    @Override
    public char charAt(int rij, int kolom) {
        return ' '; // TODO
    }

}

