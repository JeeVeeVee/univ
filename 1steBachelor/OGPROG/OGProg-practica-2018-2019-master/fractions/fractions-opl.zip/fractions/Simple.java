package fractions;

/**
 * Eenvoudige uitdrukking. Bestaat uit één enkele string.
 */
public class Simple extends Expression {

    private String text;

    public Simple(String text) {
        this.text = text;
    }

    // code niet wijzigen! Wordt gebruikt om te debuggen.
    public String toString() {
        return text;
    }

    @Override
    public void computeWidth() {
        width = text.length();
    }

    @Override
    public void computeHeightAndDepth() {
        height = 1;
        depth = 0;
    }

    @Override
    public void computeCoordinates() {
        // geen kinderen, dus hier hoeft niets te gebeuren
    }

    @Override
    public char charAt(int rij, int kolom) {
        return text.charAt (kolom - column);
    }
}
