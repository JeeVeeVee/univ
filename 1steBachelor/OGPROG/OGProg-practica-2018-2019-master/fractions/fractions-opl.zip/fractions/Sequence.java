package fractions;

import java.util.List;

/**
 * Een reeks uitdrukkingen die naast elkaar worden afgebeeld, met telkens
 * één spatie ertussen
 */
public class Sequence extends Expression {

    public Sequence(List<Expression> children) {
        this.children = children;
    }

    private List<Expression> children;

    // code niet wijzigen! Wordt gebruikt om te debuggen.
    public String toString() {
        if (children.isEmpty()) {
            return "{}";
        } else {
            StringBuilder result = new StringBuilder();
            for (Expression child : children) {
                result.append(" ").append(child);
            }
            return "{" + result.substring(1) + "}";
        }
    }


    @Override
    public void computeWidth() {

        children.forEach(Expression::computeWidth);
        // kan natuurlijk ook met een gewone for each-lus

        width = -1;
        for (Expression child : children) {
            width += child.width + 1;
        }
    }

    @Override
    public void computeHeightAndDepth() {

        children.forEach(Expression::computeHeightAndDepth);
        // kan natuurlijk ook met een gewone for each-lus

        // hoogte en diepte zijn resp. maxima van kinderen
        height = 0;
        depth = 0;
        for (Expression child : children) {
            if (child.height > height) {
                height = child.height;
            }
            if (child.depth > depth) {
                depth = child.depth;
            }
        }
    }

    @Override
    public void computeCoordinates() {

        // Horizontaal: netjes naast elkaar met een spatie ertussen
        int c = column;
        for (Expression child : children) {
            child.column = c;
            c += child.width + 1;
        }

        // Verticaal: allemaal dezelfde baseline
        for (Expression child : children) {
            child.row = row + height - child.height;
        }

        // en nu recursie
        children.forEach(Expression::computeCoordinates);
              // kan natuurlijk ook met een gewone for each-lus
              // kan zelfs onderdeel worden van de lus hierboven
    }

    @Override
    public char charAt(int rij, int kolom) {
        // Zoek eerst binnen welk kind de kolom valt
        int i = 0;
        while (i < children.size() && kolom >= children.get(i).column) {
            i ++;
        }
        Expression child = children.get(i-1);

        // Zitten we toevallig in de tussenruimte tussen twee kinderen?
        if (kolom == child.column + child.width) {
            return ' ';
        }

        // Zitten we boven of onder het kind?
        if (rij < child.row || rij >= child.row + child.getTotalHeight()) {
            return ' ';
        } else {
            return child.charAt(rij, kolom);
        }
    }

}

