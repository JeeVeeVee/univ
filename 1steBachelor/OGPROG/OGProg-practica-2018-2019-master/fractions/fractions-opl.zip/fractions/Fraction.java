package fractions;

/**
 * Een teller en noemer met een breukstreep ertussen. Teller en noemer zijn horizontaal
 * gecenteerd. Breukstreep staat op de 'baseline'.
 */
public class Fraction extends Expression {

    private Expression top;

    private Expression bottom;

    public Fraction(Expression top, Expression bottom) {
        this.top = top;
        this.bottom = bottom;
    }

    // code niet wijzigen! Wordt gebruikt om te debuggen.
    public String toString() {
        return "[" + top + "/" + bottom + "]";
    }

    @Override
    public void computeWidth() {

        bottom.computeWidth();
        top.computeWidth();

        // extra ruimte voor de breukstreep
        width = Math.max(bottom.width, top.width) + 2;
    }

    @Override
    public void computeHeightAndDepth() {

        bottom.computeHeightAndDepth();
        top.computeHeightAndDepth();

        height = top.height + top.depth + 1; // breukstreep op baseline
        depth  = bottom.height + bottom.depth;
    }

    @Override
    public void computeCoordinates() {

        // horizontaal: teller en noemer zijn gecentreerd
        int topOffset;
        int bottomOffset;
        int difference = top.width - bottom.width;
        if (difference > 0) {
            topOffset = 0;
            bottomOffset = difference/2;
        } else {
            bottomOffset = 0;
            topOffset = (-difference)/2;
        }
        top.column = column + topOffset + 1; // breukstreep is 1 langer aan beide kanten
        bottom.column = column + bottomOffset + 1;

        // verticaal
        top.row = row;
        bottom.row = row + height; // juist onder de baseline

        // recursie
        top.computeCoordinates();
        bottom.computeCoordinates();
    }

    @Override
    public char charAt(int rij, int kolom) {
        if (rij == row + height - 1) {
            return '-';
        } else if (rij > row + height -1) {
            // noemer
            return charAtChild(bottom, rij, kolom);
        } else {
            // teller
            return charAtChild(top, rij, kolom);
        }
    }

    /**
     * Hulproutine bij {2link #charAt}, toegepast op teller of noemer
     */
    private char charAtChild(Expression child, int rij, int kolom) {
        if (kolom < child.column) {
            return ' '; // links van blok
        } else if (kolom  >= child.column + child.width) {
            return ' '; // rechts van blok
        } else {
            return child.charAt(rij, kolom);
        }
    }

}
