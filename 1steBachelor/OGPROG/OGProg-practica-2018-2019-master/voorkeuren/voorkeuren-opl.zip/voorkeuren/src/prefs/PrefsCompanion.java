package prefs;

import javafx.application.Platform;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 */
public class PrefsCompanion {

    public Label minLabel;

    public Label maxLabel;

    public TextField nameField;

    public TextField firstNameField;

    public TextField minField;

    public TextField maxField;

    public ToggleButton smallButton;
    public ToggleButton mediumButton;
    public ToggleButton largeButton;

    private Map<String,ToggleButton> buttonsByName;

    public void initialize () {
        this.buttonsByName = new HashMap<String, ToggleButton>();
        buttonsByName.put ("small", smallButton);
        buttonsByName.put ("medium", mediumButton);
        buttonsByName.put ("large", largeButton);

        readProperties();

    }


    public void doSave () {
        // save and exit when no errors
        if (writeProperties()) {
            Platform.exit();
        }
    }

    public void doCancel () {
        Platform.exit();
    }

    /**
     * Leest de waarden van de eigenschappen in van het bestand my.properties
     * in de 'current directory'
     */
    private void readProperties()  {
        Properties properties = new Properties();
        try {
            properties.load(new FileReader("my.properties"));
            nameField.setText(properties.getProperty("name"));
            firstNameField.setText(properties.getProperty("firstName"));
            minField.setText(properties.getProperty("min"));
            maxField.setText(properties.getProperty("max"));

            buttonsByName.get(properties.getProperty("size"))
                    .setSelected(true);
        } catch (IOException e) {
            // er ging iets mis
        }
    }

    private boolean writeProperties() {
        boolean OK = true;

        // check min
        try {
            Integer.parseInt(minField.getText());
            minField.getStyleClass().removeAll("error");
            minLabel.getStyleClass().removeAll("error");
        } catch (NumberFormatException ex) {
            OK = false;
            minField.getStyleClass().add("error");
            minLabel.getStyleClass().add("error");
        }

        // check max
         try {
            Integer.parseInt(maxField.getText());
            maxField.getStyleClass().removeAll("error");
            maxLabel.getStyleClass().removeAll("error");
        } catch (NumberFormatException ex) {
            OK = false;
            maxField.getStyleClass().add("error");
            maxLabel.getStyleClass().add("error");
        }

        if (! OK) {
            return false;
        }

        Properties properties = new Properties();
        properties.setProperty("name", nameField.getText());
        properties.setProperty("firstName", firstNameField.getText());
        properties.setProperty("min", minField.getText());
        properties.setProperty("max", maxField.getText());

        for (Map.Entry<String, ToggleButton> entry : buttonsByName.entrySet()) {
            if (entry.getValue().isSelected()) {
                properties.setProperty("size", entry.getKey());
            }
        }

        try {
            properties.store(new FileWriter("my.properties"), " my.properties\n -------------\n\n Saved by JavaFX GUI\n");
        } catch (IOException e) {
            // er ging iets mis
        }

        return true;
    }
}
