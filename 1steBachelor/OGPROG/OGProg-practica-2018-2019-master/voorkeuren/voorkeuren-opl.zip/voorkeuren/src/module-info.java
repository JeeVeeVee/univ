open module voorkeuren {

    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.fxml;
}
