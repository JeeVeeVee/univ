package test;

public class Main {
    public static void main(String[] args){
        Integer vijf = 5;
        Integer drie = 3;
        System.out.println(vijf.compareTo(drie));
        System.out.println(drie.compareTo(vijf));
        System.out.println(drie.compareTo(drie));
    }
}
