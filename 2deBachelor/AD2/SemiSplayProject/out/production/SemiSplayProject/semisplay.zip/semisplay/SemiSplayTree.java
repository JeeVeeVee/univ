package semisplay;

import java.util.Iterator;


public class SemiSplayTree<E extends Comparable<E>> implements Iterable<E> {

    private Boomtop root;
    private int splay;
    private int depth;
    private int size;


    public SemiSplayTree(int splay){
        this.splay = splay;
        this.depth = 0;
        this.size = 0;
    }

    public Boomtop zoektop(Integer integer){
        Integer test = 0;
        Boomtop x = root;
        Boomtop prev = null;
        if (x == prev){
            depth++;
            root = new Boomtop(integer);
            return root;
        }
        while (x != null && x != prev) {
            prev = x;
            x = x.getNextTop(integer);
            System.out.println(Integer.toString(test));
            test = prev.geefWaarde();
        }
        return x;
    }

    public boolean add(Integer integer) {
        int currentDepth = 0;
        Integer test = 0;
        Boomtop x = root;
        Boomtop prev = null;
        if (x == prev){
            depth++;
            root = new Boomtop(integer);
            return true;
        }
        while (x != null && x != prev) {
            currentDepth ++;
            prev = x;
            x = x.getNextTop(integer);
            System.out.println(Integer.toString(test));
            test = prev.geefWaarde();
        }

        if (test < integer){
            prev.setGroterKind(new Boomtop(integer));
        } else if (test > integer){
            prev.setKleinerKind(new Boomtop(integer));
        }

        if (currentDepth + 1 > depth){
            depth = currentDepth + 1;
        }
        if (x == null){
            this.size++;
        }
        System.out.println("added" + Integer.toString(integer));
        return x != null;

    }

    public boolean contains(Integer integer) {
        Boomtop x = root;
        Boomtop prev = null;
        System.out.print((x.geefWaarde()));
        while (x != null && x != prev) {
            prev = x;
            x = x.getNextTop(integer);
            if (x != null) {
                System.out.print(x.geefWaarde());
            }
        }
        if (x == null){
            return false;
        } else {
            return true;
        }
    }

    public boolean remove(Integer integer) {
        Boomtop boomtop = zoektop(integer);
        if (boomtop.getKleinerKind() == null){
            return false;
        }
        return true;
        /*
        als 1 van de 2 kinderen van de top leeg is dan moet je gwn de waarde van de huidige top
        updaten naar de waarde van dat kind en het kind verwijderen
        als alle2 de kinderen van de top leeg zijn kan je de top gwn zo verwijderen

         */
    }

    public int size() {
        return size;
    }

    public int depth() {
        return depth;
    }

    public Iterator<E> iterator() {
        return null;
    }
}

