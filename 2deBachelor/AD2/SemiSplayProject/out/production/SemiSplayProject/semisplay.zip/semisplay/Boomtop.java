package semisplay;

import java.util.Iterator;

public class Boomtop {
    private Boomtop kleinerKind;
    private Boomtop groterKind;
    private Integer waarde;

    public Boomtop(Integer waarde){
        this.waarde = waarde;
        kleinerKind = null;
        groterKind = null;
    }

    public Boomtop getNextTop(Integer integer){
        if (integer > waarde){
            return groterKind;
        } else if (integer < waarde){
            return kleinerKind;
        } else{
            return this;
        }
    }

    public void setKleinerKind(Boomtop boomtop){
        this.kleinerKind = boomtop;
    }

    public void setGroterKind(Boomtop boomtop){
        this.groterKind = boomtop;
    }

    public Integer geefWaarde(){
        return this.waarde;
    }

    public Boomtop getKleinerKind(){
        return this.kleinerKind;
    }

    public Boomtop getGroterKind(){
        return this.groterKind;
    }
}
