package test;

import org.junit.*;

public class Tester {
    @BeforeClass
    public static void setUpBeforeClass(){

    }

    @Before
    public void setUp(){

    }

    @Test
    public void test(){

    }

    @After
    public void tearDown(){

    }



    @AfterClass
    public static void tearDownAfterClass(){

    }

}
